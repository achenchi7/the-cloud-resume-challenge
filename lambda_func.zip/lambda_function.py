import json
import boto3
import os

# Initialize DynamoDB resource
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')

# Get the table name from environment variables (optional)

table = dynamodb.Table('visitor-count-terraform2-v2')

def lambda_handler(event, context):
    # Retrieve current visitor count from DynamoDB
    response = table.get_item(
        Key={'id': 'visitors-count'}  # Using 'id' as the key, and 'visitors-count' as the value
    )
    
    # Check if the item exists in the response
    item = response.get("Item", None)
    
    # If the item doesn't exist, create a new entry with visits set to 0
    if item is None:
        visits = 0
        table.put_item(Item={"id": "visitors-count", "visits": visits})
    else:
        # If item exists, get the current visit count and increment it
        visits = int(item.get("visits", 0))  # Use 'visits' field to get the current count
        visits += 1
        # Update DynamoDB with new visitor count
        table.put_item(Item={"id": "visitors-count", "visits": visits})

    # Return the updated visitor count
    return {
        "statusCode": 200,
        "body": json.dumps({"visitor_count": visits})
    }
